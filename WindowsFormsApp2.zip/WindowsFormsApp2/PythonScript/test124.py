import sqlite3
dbname='TEST0.db'
conn=sqlite3.connect(dbname)
conn.row_factory=sqlite3.Row
cur=conn.cursor()
#cur.execute('CREATE TABLE person(id INTEGER PRIMARY KEY AUTOINCREMENT,name STRING,voice INTEGER,speed REAL)')
#cur.execute('INSERT INTO person values(1,"Yamamoto",0,0.7)')
#cur.execute('INSERT INTO person values(2,"Yamato",1,1)')
#cur.execute('INSERT INTO person values(3,"Yamoto",2,1.5)')
conn.commit()
cur.execute('SELECT * FROM person')
for row in cur.fetchall():
    print(row["name"])
    print(row["voice"])
    print(row["speed"])

cur.close()
conn.close()