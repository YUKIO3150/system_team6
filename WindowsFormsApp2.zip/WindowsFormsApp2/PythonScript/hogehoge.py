# hogehoge.py
def foo(val):
    val += 5
    print("",val)
    return f"result {val}"

if __name__ == '__main__':
    foo(12)