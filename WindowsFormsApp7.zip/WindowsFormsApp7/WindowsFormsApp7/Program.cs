﻿using System;
using System.Diagnostics;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
        static public string[] python()
        {
            //下記のPythonスクリプトへのファイルパスを記述する
            string myPythonApp = "E:\\test124.py";

            var myProcess = new Process
            {
                StartInfo = new ProcessStartInfo("C:\\Program Files\\Python38\\python.exe")
                {
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    Arguments = myPythonApp
                }
            };

            myProcess.Start();

            int n = 0;
            string[] hairetu = new string[100];
            StreamReader myStreamReader = myProcess.StandardOutput;
            while (myStreamReader.Peek() != -1)
            {
                //StreamReader myStreamReader = myProcess.StandardOutput;
                //for (int f = 0; f <= n - 1; f++)
                //{
                //string myString = myStreamReader.ReadLine();
                //hairetu[i] = myString;
                //}
                string myString = myStreamReader.ReadLine();
                hairetu[n] = Convert.ToString(myString);
                n++;
            }
            //while (myStreamReader.EndOfStream==false)
            //{
            //string myString = myStreamReader.ReadLine();
            //hairetu[n] = myString;
            //n++;
            //}
            myProcess.WaitForExit();
            myProcess.Close();
            return hairetu;
        }
    }
}